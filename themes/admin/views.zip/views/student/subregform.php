<?php
$this->breadcrumbs=array(
	'Student'=>array('studentlist'),
	'Course Registration',
);
?>

<?php $form=$this->beginWidget('booster.widgets.TbActiveForm',array(
		'id'=>'sub-reg-form',
		'type' => 'horizontal',
		'enableAjaxValidation'=>false,
)); ?>
<?php
	$this->widget('booster.widgets.TbAlert', array(
    'alerts'=>array( // configurations per alert type
        'fade'=>true, // use transitions?
		'closeText'=>'&times;',
        'error'=>array('block'=>true, 'fade'=>true, 'closeText'=>'&times;'), // success, info, warning, error or danger,
    ),
));
?>
<div class="row">
<div class="col-md-12">
<div class="panel">
	<div class="panel-heading">
		<span class="panel-title">Course Registration</span>
	</div>
	<div class="panel-body">
	<div class="col-md-6">
	<table class="table table-hover table-bordered  table-striped ">
							<tr>
								<th>Student Name</th>
								<td><?php  echo $student_obj->name; ?></td>
							</tr>
							<tr>
								<th>ID</th>
								<td><?php echo $student_obj->student_id;?></td>
							</tr>
							<tr>
							   <th>Class</th>
							   <td><?php echo $student_obj->class_name ?></td>
							</tr>
					
						<tr>	
							<th>Group</th>
							<td><?php echo ucfirst($student_obj->group); ?></td>
							
						</tr>
							<tr>	
							<th>Section</th>
							<td><?php echo $student_obj->section_name ?></td>
							
						</tr>
						<tr>	
							<th>Roll No</th>
							<td><?php echo $student_obj->roll_no ?></td>
							
						</tr>
						<tr>	
							<th>Year</th>
							<td><?php echo $student_obj->year_name ?></td>
							
						</tr>
					</table>	
	</div>
	<div class="col-md-6">
	<h2>Compulsory Subject</h2>
    	<?php foreach(Subjects::sub_list($student_obj->class_id,$student_obj->group) as $key=>$sub): ?>
    	<div class="checkbox-custom checkbox-primary mb5">
	   <?php 

		echo CHtml::checkbox('sub['.$key.']',isset($student_sub_arr[$key])?(strlen($student_sub_arr[$key])>0?true:false):false,array('id'=>$key,'value'=>$key,/*'class'=>'checkbox_class'*/));
		echo CHtml::label($sub,$key);
		?>
		</div>
		<?php endforeach; ?>
	
	 <h2>Group Subject</h2>	
	<?php foreach(Subjects::sub_list($student_obj->class_id,$student_obj->group,1) as $key=>$sub): ?>
    	<div class="checkbox-custom checkbox-primary mb5">
	   <?php 

		echo CHtml::checkbox('sub['.$key.']',isset($student_sub_arr[$key])?(strlen($student_sub_arr[$key])>0?true:false):false,array('id'=>$key,'value'=>$key,/*'class'=>'checkbox_class'*/));
		echo CHtml::label($sub,$key);
		?>
		</div>
		<?php endforeach; ?>   
     <h2>Elective Subject</h2>
    <div class="col-md-12">
     <?php foreach(Subjects::sub_list($student_obj->class_id,$student_obj->group,2) as $key=>$sub): ?>
      <div class="col-md-4">
    	<div class="radio-custom radio-primary mb5">
	   <?php 

		echo CHtml::radioButton('elective_sub',isset($student_elec_sub_arr[$key])?(strlen($student_elec_sub_arr[$key])>0?true:false):false,array('id'=>$key.'2','value'=>$key,/*'class'=>'checkbox_class'*/));
		echo CHtml::label($sub,$key.'2');
		?>
		</div>
			</div>
		<?php endforeach; ?>
	</div>
		<div class="form-actions">
			<?php $this->widget('booster.widgets.TbButton', array(
					'buttonType'=>'submit',
					'context'=>'primary',
					'label'=>'Submit',
		)); ?>
		</div>
	</div>
</div>
</div>



<?php $this->endWidget(); ?>
</div>
</div>