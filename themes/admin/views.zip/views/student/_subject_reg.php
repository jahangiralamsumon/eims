<?php if($action=='update'){?>
<?php
$this->breadcrumbs=array(
		'Students'=>array('studentlist'),
		$student_obj->name=>array('view','id'=>$student_obj->student_id),
		'Update',
);

?>

<h1>
	Update Student
	<?php echo $student_obj->student_id; ?>
</h1>
<?php  } else{?>
<?php
$this->breadcrumbs=array(
	'Students'=>array('studentlist'),
	'Create',
);

?>

<h1>New Admission</h1>
<?php }?>