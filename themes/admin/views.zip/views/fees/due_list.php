<?php
$this->breadcrumbs=array(
		'Fees'=>array(''),
		'Due List',
);
?>
<div class="row">

	<?php 
	if(isset($data)):

	?>
	<div class="col-md-12">
		<div class="panel">
			<div class="panel-heading">
				<span class="panel-title">Fee Due List</span>
			</div>
			<div class="panel-body">
				<div class="invoice-buttons">
					<a href="javascript:window.print()" class="btn btn-default mr10"><i
						class="fa fa-print pr5"></i> Print</a>
				</div>
				<h2 style="text-align: center;">
					Due List as on Date  <small>(<?php echo date("d-M-Y") ?>
						)
					</small>
				</h2>

				<div class="row">
					<div class="col-md-12">
					 <?php 
					 $classes=Classes::items();
					 
					 foreach ($classes as $class_id=>$class):
					 
					
					 ?>
						<h2><?php echo $class  ?></h2>
					
						<table class="items table table-striped table-bordered">
							<tr>
								<th>Student ID</th>
								<th>Student Name</th>
								<th>Amount</th>

							</tr>

							<?php 
							$total_balance=0;
							foreach ($data as $key=> $row):

							if($row['balance']>0 && $class_id==$row['class_id'] )
							{
							
									$total_balance=$total_balance+$row['balance'];
								
							?>
							<tr>
								<td><?php echo $row['student_id']?></td>
								<td><?php echo $row['student_name']?></td>
								<td><?php echo number_format($row['balance'],2,'.','') ; ?>
								</td>

							</tr>
							<?php												
							}

							endforeach;
							?>
                           <tr>
						<th>Total Due</th>
						<th colspan="2">
						<?php
						
						echo number_format($total_balance,2,'.','');
						
						?>
						</th>
						
					
					</tr>
						</table>
						<?php 
						endforeach;
						?>
					</div>


				</div>
			</div>
		</div>
	</div>
	<?php endif;?>
</div>

